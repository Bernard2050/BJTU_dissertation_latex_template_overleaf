testfiledir = "testfiles/01-title-page-en"
testsuppdir = testfiledir .. "/support"

includetests = {"*"}
excludetests = {}
