testfiledir = "testfiles/01-title-page"
testsuppdir = testfiledir .. "/support"

includetests = {"*"}
excludetests = {}
