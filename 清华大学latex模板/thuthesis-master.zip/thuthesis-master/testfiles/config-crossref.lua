includetests = {
  "06-*",
  "07-*",
  "09-*",
  "package-hyperref",
}
excludetests = {}

checkruns = 2
