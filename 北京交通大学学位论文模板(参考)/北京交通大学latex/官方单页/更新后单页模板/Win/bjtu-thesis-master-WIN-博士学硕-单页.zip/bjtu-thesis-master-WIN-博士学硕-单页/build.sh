rm *.aux *.log *.toc *.synctex.gz *.out chapters/*.aux *.bbl *.blg
